# ! /bin/bash
# Programa para ejemplificar como se realiza el paso de opciones con o sin parametros
# Autor: Wilder David

echo "Programa Opciones"
echo "Opción 1 Enviada: $1"
echo "Opción 2 Enviada: $2"
echo "Opción enviadas: $*"
echo "\n"
echo "Recuperar valores"
while [ -n "$1" ]
do
case "$1" in
-a) echo "-a option utilizada";;
-b) echo "-b option utilizada";;
-c) echo "-c option utilizada";;
-*) echo "$! no es una opción";;
esac
shift
done
